import {createClient} from '@supabase/supabase-js';
const db=createClient(process.env.NEXT_PUBLIC_SUPABASE_URL,process.env.SUPABASE_SERVICE_ROLE_KEY);
export async function GET(){const {data,error}=await db.from('pdfs').select('*').order('created_at',{ascending:false}); if(error)return Response.json({error:error.message},{status:500}); return Response.json(data||[])}
